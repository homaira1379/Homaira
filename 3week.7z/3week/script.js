// ===== Reader Info =====
const readerName = "Homaira Yousufi";    // ← change to your name
const currentMonth = "September";        // ← change to current month

console.log(`Reader: ${readerName}`);
console.log(`Month: ${currentMonth}`);
console.log("-------------------------");

// ===== Book Data =====
const bookTitles = [
  "Pride and Prejudice",
  "JavaScript: The Good Parts",
  "The Kite Runner"
];
const totalPages = [279, 176, 371];
const pagesRead  = [150, 100, 40];

// ===== Functions =====
function calculateProgress(pagesRead, totalPages) {
  return Math.round((pagesRead / totalPages) * 100);
}

function getReadingStatus(progressPercent) {
  if (progressPercent === 100) return "Finished";
  if (progressPercent >= 50)  return "In Progress";
  return "Just Started";
}

function printBookSummary(title, pagesRead, totalPages) {
  const percent = calculateProgress(pagesRead, totalPages);
  const status  = getReadingStatus(percent);
  console.log(`Title: ${title} — ${pagesRead}/${totalPages} pages read — ${status}`);
}

function totalPagesRead(pagesReadArray) {
  let total = 0;
  for (let i = 0; i < pagesReadArray.length; i++) {
    total += pagesReadArray[i];
  }
  return total;
}

function findBookWithMostPagesLeft(titlesArray, pagesReadArray, totalPagesArray) {
  let maxLeft = 0;
  let bookTitle = "";
  for (let i = 0; i < titlesArray.length; i++) {
    const left = totalPagesArray[i] - pagesReadArray[i];
    if (left > maxLeft) {
      maxLeft = left;
      bookTitle = titlesArray[i];
    }
  }
  return bookTitle;
}

function printReadingSummary(readerName, month, pagesReadArray) {
  const totalRead = totalPagesRead(pagesReadArray);
  console.log(`${readerName}'s reading progress for ${month}: ${totalRead} pages read.`);
}

// ===== Output =====
for (let i = 0; i < bookTitles.length; i++) {
  printBookSummary(bookTitles[i], pagesRead[i], totalPages[i]);
}
console.log("-------------------------");

printReadingSummary(readerName, currentMonth, pagesRead);
console.log(`Book with the most pages left: ${findBookWithMostPagesLeft(bookTitles, pagesRead, totalPages)}`);
