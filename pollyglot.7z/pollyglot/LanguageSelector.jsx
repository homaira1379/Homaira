export default function LanguageSelector({ lang, setLang }) {
  const options = ["French", "Spanish", "Japanese"];
  return (
    <div>
      {options.map((l) => (
        <label key={l}>
          <input
            type="radio"
            name="lang"
            value={l}
            checked={lang === l}
            onChange={() => setLang(l)}
          />
          {l}
        </label>
      ))}
    </div>
  );
}
