import { useLocation, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import OpenAI from "openai";

export default function Result() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const [translation, setTranslation] = useState("");

  useEffect(() => {
    async function fetchTranslation() {
      const client = new OpenAI({
        apiKey: import.meta.env.VITE_OPENAI_KEY,
        dangerouslyAllowBrowser: true
      });
      const prompt = `Translate the following text into ${state.lang}: "${state.text}"`;
      const res = await client.chat.completions.create({
        model: "gpt-4",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.4,
        max_tokens: 200
      });
      setTranslation(res.choices[0].message.content.trim());
    }
    fetchTranslation();
  }, [state]);

  return (
    <main className="result">
      <h2>Your Translation</h2>
      <p><strong>Original:</strong> {state.text}</p>
      <p><strong>Translated:</strong> {translation || "Translating..."}</p>
      <button onClick={() => navigate("/")}>Start Over</button>
    </main>
  );
}
